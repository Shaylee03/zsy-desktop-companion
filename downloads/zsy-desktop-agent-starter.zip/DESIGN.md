# Desktop Context Design

## Principle

Desktop context is not a single robot state. It is one input track.

Existing backend-owned tracks stay separate:

- Interaction: idle, active chat, speaking.
- Tasks: focus, countdown, reminder.
- Desktop context: coding, meeting, WeChat, browser, away.
- Attention policy: final backend decision.

The local agent only produces desktop context and an attention hint. It must not
decide whether the robot should speak.

## Collection Model

This follows the useful part of ActivityWatch's design: watch continuously,
store the latest state locally, then let consumers read that state cheaply.

The web panel does not trigger full desktop inspection on every refresh. A
background sampler updates foreground-window and idle signals every 0.5s,
refreshes the heavier WeChat process check every 3s, and probes ActivityWatch
every 5s. This makes the agent feel more immediate without coupling robot
behavior to raw noisy events.

## Why This Avoids Conflicts

A countdown can run while the user is coding. A reminder can be pending while
the user is in a meeting. A focus timer can run while WeChat is in the
background.

So the backend should combine tracks like this:

```text
presentation = policy(interaction, tasks, desktop_context, attention_hint)
```

Examples:

```text
interaction=idle, task=countdown, desktop=coding
  -> screen can show TIMER 02:31, robot stays quiet.

interaction=active_chat, task=countdown, desktop=coding
  -> screen prioritizes LISTEN/THINK/SPEAK, countdown remains backend-owned.

interaction=idle, task=reminder, desktop=meeting
  -> robot should not speak immediately; delay or display silently.
```

## First Local Agent Scope

Implemented now:

- Foreground process and title.
- Keyboard/mouse idle seconds.
- Background sampling/cache so the panel reads recent state instead of blocking
  on slow process queries.
- WeChat L1-L2:
  - process running;
  - foreground;
  - WeChat-owned window titles only;
  - conservative unread hint.
- ActivityWatch compatibility probe:
  - detects whether `http://127.0.0.1:5600` is reachable;
  - lists available buckets;
  - reads the latest current-window event;
  - reads the latest AFK status event;
  - summarizes recent 30-minute app usage;
  - summarizes recent active/AFK time.

Not implemented yet:

- Reading WeChat message content.
- Sending WeChat messages.
- Robot policy decisions.
- Automatic backend posting loop.

Those should come only after the visible panel proves that the collected data is
stable on the user's machine.

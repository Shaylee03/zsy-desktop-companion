﻿#!/usr/bin/env python3
"""Local desktop rhythm agent.

This is a visible, testable local observer. It does not control the robot.
It exposes a web panel plus JSON state so we can validate desktop sensing
before wiring it into backend policy.
"""

from __future__ import annotations

import ctypes
import ctypes.wintypes as wintypes
import json
import os
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
import winreg
from collections import deque
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import quote


HOST = "127.0.0.1"
PORT = int(os.getenv("DESKTOP_AGENT_PORT", "8765"))
ACTIVITYWATCH_URL = os.getenv("ACTIVITYWATCH_URL", "http://127.0.0.1:5600")
BACKEND_DESKTOP_CONTEXT_URL = os.getenv(
    "DESKTOP_AGENT_BACKEND_URL",
    "http://127.0.0.1:8000/desktop-context",
)
SAMPLE_INTERVAL_SECONDS = float(os.getenv("DESKTOP_AGENT_SAMPLE_INTERVAL", "0.5"))
WECHAT_PROCESS_INTERVAL_SECONDS = float(os.getenv("DESKTOP_AGENT_WECHAT_INTERVAL", "3.0"))
ACTIVITYWATCH_INTERVAL_SECONDS = float(os.getenv("DESKTOP_AGENT_AW_INTERVAL", "5.0"))
ACTIVITYWATCH_LOOKBACK_MINUTES = int(os.getenv("DESKTOP_AGENT_AW_LOOKBACK_MINUTES", "120"))
BACKEND_POST_INTERVAL_SECONDS = float(os.getenv("DESKTOP_AGENT_BACKEND_INTERVAL", "5.0"))
BACKEND_POST_ENABLED = os.getenv("DESKTOP_AGENT_POST_BACKEND", "1").strip().lower() not in {"0", "false", "no", "off"}
BACKEND_DEBUG_TOKEN = os.getenv("DESKTOP_AGENT_DEBUG_TOKEN", os.getenv("ADMIN_API_TOKEN", os.getenv("DEBUG_API_TOKEN", ""))).strip()


user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32]
kernel32.OpenProcess.restype = ctypes.c_void_p
kernel32.QueryFullProcessImageNameW.argtypes = [
    ctypes.c_void_p,
    ctypes.c_uint32,
    ctypes.c_wchar_p,
    ctypes.POINTER(ctypes.c_uint32),
]
kernel32.QueryFullProcessImageNameW.restype = ctypes.c_bool
kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
kernel32.CloseHandle.restype = ctypes.c_bool
kernel32.GetTickCount64.restype = ctypes.c_ulonglong
user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.GetAsyncKeyState.restype = ctypes.c_short
user32.SetWindowsHookExW.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32]
user32.SetWindowsHookExW.restype = ctypes.c_void_p
user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p]
user32.CallNextHookEx.restype = ctypes.c_void_p
user32.GetMessageW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
user32.GetMessageW.restype = ctypes.c_int

_pid_name_cache: dict[int, str] = {}
_wechat_process_cache = {"checked_at": 0.0, "count": 0}
_system_info_cache = {"checked_at": 0.0, "value": None}
_activitywatch_cache = None
_mouse_click_times: deque[float] = deque(maxlen=500)
_key_press_times: deque[float] = deque(maxlen=2000)
_scroll_times: deque[float] = deque(maxlen=1000)
_last_mouse_down = {0x01: False, 0x02: False, 0x04: False}
_last_key_down = {vk: False for vk in range(0x08, 0xFF) if vk not in _last_mouse_down}
_last_foreground_key = ""
_foreground_since = time.time()
_session_started_at = time.time()
_was_input_idle = False
_mouse_hook_handle = None
_mouse_hook_callback = None
_state_lock = threading.Lock()
_latest_state: "AgentState | None" = None
_post_lock = threading.Lock()
_last_post_result: dict[str, Any] = {
    "enabled": BACKEND_POST_ENABLED,
    "url": BACKEND_DESKTOP_CONTEXT_URL,
    "ok": False,
    "sent_at": 0.0,
    "error": "not sent yet",
}


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_uint),
        ("dwTime", ctypes.c_uint),
    ]


class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("pt_x", ctypes.c_long),
        ("pt_y", ctypes.c_long),
        ("mouseData", ctypes.c_uint32),
        ("flags", ctypes.c_uint32),
        ("time", ctypes.c_uint32),
        ("dwExtraInfo", ctypes.c_void_p),
    ]


WH_MOUSE_LL = 14
WM_MOUSEWHEEL = 0x020A
LowLevelMouseProc = ctypes.WINFUNCTYPE(ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p)


@dataclass
class WindowInfo:
    process_id: int = 0
    process_name: str = ""
    title: str = ""
    idle_seconds: int = 0
    foreground_duration: float = 0.0


@dataclass
class WeChatInfo:
    running: bool = False
    foreground: bool = False
    process_count: int = 0
    window_titles: list[str] = field(default_factory=list)
    unread_hint: str = "unknown"


@dataclass
class InputActivity:
    recent_mouse_clicks_60s: int = 0
    mouse_clicks_last_60s: int = 0
    keys_last_60s: int = 0
    scroll_events_last_60s: int = 0
    idle_seconds: int = 0


@dataclass
class DeviceActivity:
    camera_active: bool | None = None
    mic_active: bool | None = None
    audio_playing: bool | None = None
    active_camera_sources: list[str] = field(default_factory=list)
    active_mic_sources: list[str] = field(default_factory=list)
    active_audio_sessions: list[str] = field(default_factory=list)


@dataclass
class SignalQuality:
    keyboard: str = "available"
    mouse: str = "available"
    scroll: str = "available"
    foreground: str = "available"
    camera: str = "unavailable"
    mic: str = "unavailable"
    audio: str = "unavailable"


@dataclass
class ActivityWatchWindow:
    bucket: str = ""
    app: str = ""
    title: str = ""
    timestamp: str = ""
    duration: float = 0.0


@dataclass
class ActivityWatchAfk:
    bucket: str = ""
    status: str = ""
    timestamp: str = ""
    duration: float = 0.0


@dataclass
class ActivityWatchAppUsage:
    app: str = ""
    seconds: float = 0.0
    events: int = 0
    percent: float = 0.0


@dataclass
class ActivityWatchInfo:
    reachable: bool = False
    url: str = ACTIVITYWATCH_URL
    buckets: list[str] = field(default_factory=list)
    window_bucket: str = ""
    afk_bucket: str = ""
    latest_window: ActivityWatchWindow = field(default_factory=ActivityWatchWindow)
    latest_afk: ActivityWatchAfk = field(default_factory=ActivityWatchAfk)
    recent_windows: list[ActivityWatchWindow] = field(default_factory=list)
    top_apps_30m: list[ActivityWatchAppUsage] = field(default_factory=list)
    window_observed_seconds_30m: float = 0.0
    active_seconds_30m: float = 0.0
    afk_seconds_30m: float = 0.0
    lookback_minutes: int = ACTIVITYWATCH_LOOKBACK_MINUTES
    error: str = ""


@dataclass
class DerivedContext:
    activity: str = "unknown"
    attention_hint: str = "allow_speak"
    reason: str = ""


@dataclass
class EffectiveWindow:
    app: str = ""
    title: str = ""
    duration: float = 0.0
    source: str = "native"
    reason: str = ""


@dataclass
class ProcessSummary:
    name: str = ""
    count: int = 0


@dataclass
class VisibleWindowSummary:
    process_name: str = ""
    title: str = ""
    process_id: int = 0


@dataclass
class SystemInfo:
    uptime_seconds: int = 0
    process_count: int = 0
    running_processes: list[ProcessSummary] = field(default_factory=list)
    visible_windows: list[VisibleWindowSummary] = field(default_factory=list)
    collected_at: float = 0.0


@dataclass
class AgentState:
    agent: str = "running"
    hostname: str = socket.gethostname()
    collected_at: float = 0.0
    sample_interval_seconds: float = SAMPLE_INTERVAL_SECONDS
    session_started_at: float = field(default_factory=lambda: _session_started_at)
    session_duration: float = 0.0
    active_window: WindowInfo = field(default_factory=WindowInfo)
    input_activity: InputActivity = field(default_factory=InputActivity)
    device_activity: DeviceActivity = field(default_factory=DeviceActivity)
    signal_quality: SignalQuality = field(default_factory=SignalQuality)
    wechat: WeChatInfo = field(default_factory=WeChatInfo)
    activitywatch: ActivityWatchInfo = field(default_factory=ActivityWatchInfo)
    system: SystemInfo = field(default_factory=SystemInfo)
    derived: DerivedContext = field(default_factory=DerivedContext)


_activitywatch_cache = ActivityWatchInfo()


def _decode_output(raw: bytes) -> str:
    for encoding in ("utf-8-sig", "gbk", "utf-16"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def get_idle_seconds() -> int:
    info = LASTINPUTINFO()
    info.cbSize = ctypes.sizeof(LASTINPUTINFO)
    if not user32.GetLastInputInfo(ctypes.byref(info)):
        return 0
    elapsed_ms = kernel32.GetTickCount() - info.dwTime
    return max(0, int(elapsed_ms / 1000))


def mouse_hook_loop() -> None:
    global _mouse_hook_handle, _mouse_hook_callback

    @_low_level_mouse_callback
    def callback(n_code, w_param, l_param):
        if n_code >= 0 and int(w_param) == WM_MOUSEWHEEL:
            _scroll_times.append(time.time())
        return user32.CallNextHookEx(_mouse_hook_handle, n_code, w_param, l_param)

    _mouse_hook_callback = callback
    _mouse_hook_handle = user32.SetWindowsHookExW(WH_MOUSE_LL, _mouse_hook_callback, None, 0)
    if not _mouse_hook_handle:
        print("Mouse wheel hook unavailable; scroll_events_last_60s will stay 0.")
        return
    msg = wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
        pass


def _low_level_mouse_callback(func):
    return LowLevelMouseProc(func)


def get_input_activity() -> InputActivity:
    now = time.time()
    cutoff = now - 60
    while _mouse_click_times and _mouse_click_times[0] < cutoff:
        _mouse_click_times.popleft()
    while _key_press_times and _key_press_times[0] < cutoff:
        _key_press_times.popleft()
    while _scroll_times and _scroll_times[0] < cutoff:
        _scroll_times.popleft()

    for vk in list(_last_mouse_down):
        down = bool(user32.GetAsyncKeyState(vk) & 0x8000)
        if down and not _last_mouse_down[vk]:
            _mouse_click_times.append(now)
        _last_mouse_down[vk] = down
    for vk in list(_last_key_down):
        down = bool(user32.GetAsyncKeyState(vk) & 0x8000)
        if down and not _last_key_down[vk]:
            _key_press_times.append(now)
        _last_key_down[vk] = down

    return InputActivity(
        recent_mouse_clicks_60s=len(_mouse_click_times),
        mouse_clicks_last_60s=len(_mouse_click_times),
        keys_last_60s=len(_key_press_times),
        scroll_events_last_60s=len(_scroll_times),
        idle_seconds=get_idle_seconds(),
    )


def get_foreground_window() -> WindowInfo:
    global _last_foreground_key, _foreground_since
    hwnd = user32.GetForegroundWindow()
    title_buffer = ctypes.create_unicode_buffer(512)
    user32.GetWindowTextW(hwnd, title_buffer, 512)
    pid = ctypes.c_ulong()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    process_name = get_process_name(pid.value)
    key = f"{process_name}|{title_buffer.value}"
    now = time.time()
    if key != _last_foreground_key:
        _last_foreground_key = key
        _foreground_since = now
    return WindowInfo(
        process_id=int(pid.value),
        process_name=process_name,
        title=title_buffer.value,
        idle_seconds=get_idle_seconds(),
        foreground_duration=max(0.0, now - _foreground_since),
    )


def get_process_name(pid: int) -> str:
    if not pid:
        return ""
    cached = _pid_name_cache.get(pid)
    if cached:
        return cached

    process = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
    if process:
        try:
            size = ctypes.c_uint32(260)
            buffer = ctypes.create_unicode_buffer(size.value)
            if kernel32.QueryFullProcessImageNameW(process, 0, buffer, ctypes.byref(size)):
                name = os.path.basename(buffer.value)
                if name:
                    _pid_name_cache[pid] = name
                    return name
        finally:
            kernel32.CloseHandle(process)

    try:
        raw = subprocess.check_output(
            ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
            stderr=subprocess.DEVNULL,
            timeout=0.5,
        )
        text = _decode_output(raw).strip()
        if not text or "INFO:" in text:
            return ""
        name = next(csv_split(text))[0]
        _pid_name_cache[pid] = name
        return name
    except Exception:
        return ""


def get_device_activity() -> tuple[DeviceActivity, SignalQuality]:
    device = DeviceActivity()
    quality = SignalQuality(camera="available", mic="available", audio="available")
    try:
        mic_active, mic_sources = read_capability_active("microphone")
        device.mic_active = mic_active
        device.active_mic_sources = mic_sources
    except Exception as exc:
        quality.mic = f"unavailable: {exc}"
        device.mic_active = None
    try:
        camera_active, camera_sources = read_capability_active("webcam")
        device.camera_active = camera_active
        device.active_camera_sources = camera_sources
    except Exception as exc:
        quality.camera = f"unavailable: {exc}"
        device.camera_active = None
    try:
        audio_playing, sessions = read_audio_playing()
        device.audio_playing = audio_playing
        device.active_audio_sessions = sessions
    except Exception as exc:
        quality.audio = f"unavailable: {exc}"
        device.audio_playing = None
    return device, quality


def read_capability_active(capability: str) -> tuple[bool, list[str]]:
    base = rf"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\{capability}"
    active_sources: list[str] = []
    try:
        root = winreg.OpenKey(winreg.HKEY_CURRENT_USER, base)
    except FileNotFoundError:
        return False, []

    def scan_key(key, name_prefix: str = ""):
        try:
            value, _ = winreg.QueryValueEx(key, "Value")
        except OSError:
            value = ""
        try:
            start, _ = winreg.QueryValueEx(key, "LastUsedTimeStart")
        except OSError:
            start = 0
        try:
            stop, _ = winreg.QueryValueEx(key, "LastUsedTimeStop")
        except OSError:
            stop = 0
        if str(value).lower() != "deny" and int(start or 0) > int(stop or 0):
            active_sources.append(name_prefix or "(root)")
        index = 0
        while True:
            try:
                child_name = winreg.EnumKey(key, index)
            except OSError:
                break
            try:
                child = winreg.OpenKey(key, child_name)
                scan_key(child, child_name)
                winreg.CloseKey(child)
            except OSError:
                pass
            index += 1

    scan_key(root)
    winreg.CloseKey(root)
    return bool(active_sources), active_sources[:8]


def read_audio_playing() -> tuple[bool, list[str]]:
    import comtypes
    from pycaw.pycaw import AudioUtilities

    comtypes.CoInitialize()
    sessions = AudioUtilities.GetAllSessions()
    active: list[str] = []
    for session in sessions:
        # Windows AudioSessionStateActive is 1. Some pycaw releases do not export
        # the enum name, so keep the check numeric and explicit.
        if int(session.State) != 1:
            continue
        name = ""
        try:
            if session.Process:
                name = session.Process.name()
        except Exception:
            name = ""
        try:
            volume = session.SimpleAudioVolume
            if volume.GetMute() or volume.GetMasterVolume() <= 0.01:
                continue
        except Exception:
            pass
        active.append(name or session.DisplayName or "(audio-session)")
    return bool(active), sorted(set(active))[:8]


def update_session_timing(input_activity: InputActivity) -> tuple[float, float]:
    global _session_started_at, _was_input_idle
    idle_now = (
        input_activity.idle_seconds >= 300
        and input_activity.keys_last_60s == 0
        and input_activity.mouse_clicks_last_60s == 0
        and input_activity.scroll_events_last_60s == 0
    )
    if _was_input_idle and not idle_now:
        _session_started_at = time.time()
    _was_input_idle = idle_now
    return _session_started_at, max(0.0, time.time() - _session_started_at)


def csv_split(line: str):
    # Small CSV parser for tasklist output. Avoid importing pandas or pywin32.
    import csv
    from io import StringIO

    return csv.reader(StringIO(line))


def list_windows() -> list[tuple[int, int, str, str]]:
    windows: list[tuple[int, int, str, str]] = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def enum_proc(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        pid = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        windows.append((int(hwnd), int(pid.value), get_process_name(pid.value), buf.value))
        return True

    user32.EnumWindows(enum_proc, 0)
    return windows


def get_system_info() -> SystemInfo:
    now = time.monotonic()
    cached = _system_info_cache.get("value")
    if cached and now - float(_system_info_cache.get("checked_at") or 0.0) < 10.0:
        return cached

    process_counts: dict[str, int] = {}
    try:
        raw = subprocess.check_output(
            ["tasklist", "/FO", "CSV", "/NH"],
            stderr=subprocess.DEVNULL,
            timeout=5.0,
        )
        text = _decode_output(raw)
        for row in csv_split(text):
            if not row:
                continue
            name = str(row[0] or "").strip()
            if not name:
                continue
            process_counts[name] = process_counts.get(name, 0) + 1
    except Exception:
        previous = _system_info_cache.get("value")
        if isinstance(previous, SystemInfo) and previous.running_processes:
            process_counts = {item.name: int(item.count) for item in previous.running_processes}
        else:
            process_counts = {}

    visible_windows: list[VisibleWindowSummary] = []
    seen_windows: set[tuple[str, str, int]] = set()
    for _hwnd, pid, process_name, title in list_windows():
        if not process_name and not title:
            continue
        key = (process_name, title, pid)
        if key in seen_windows:
            continue
        seen_windows.add(key)
        visible_windows.append(VisibleWindowSummary(process_name=process_name, title=title[:160], process_id=pid))
        if len(visible_windows) >= 80:
            break
    running_processes = [
        ProcessSummary(name=name, count=count)
        for name, count in sorted(process_counts.items(), key=lambda item: (-item[1], item[0].lower()))[:120]
    ]
    info = SystemInfo(
        uptime_seconds=int(kernel32.GetTickCount64() / 1000),
        process_count=sum(process_counts.values()),
        running_processes=running_processes,
        visible_windows=visible_windows,
        collected_at=time.time(),
    )
    _system_info_cache["checked_at"] = now
    _system_info_cache["value"] = info
    return info


def get_wechat_info(active: WindowInfo) -> WeChatInfo:
    info = WeChatInfo()
    now = time.monotonic()
    if now - float(_wechat_process_cache["checked_at"]) >= WECHAT_PROCESS_INTERVAL_SECONDS:
        count = 0
        try:
            for image_name in ("WeChat.exe", "Weixin.exe"):
                raw = subprocess.check_output(
                    ["tasklist", "/FI", f"IMAGENAME eq {image_name}", "/FO", "CSV", "/NH"],
                    stderr=subprocess.DEVNULL,
                    timeout=0.5,
                )
                text = _decode_output(raw).strip()
                rows = [row for row in csv_split(text) if row and row[0].lower() == image_name.lower()]
                count += len(rows)
            _wechat_process_cache["count"] = count
        except Exception:
            _wechat_process_cache["count"] = 0
        _wechat_process_cache["checked_at"] = now

    info.process_count = int(_wechat_process_cache["count"])
    info.running = info.process_count > 0

    info.foreground = active.process_name.lower() in ("wechat.exe", "weixin.exe")
    titles = []
    for _hwnd, _pid, process_name, title in list_windows():
        if process_name.lower() in ("wechat.exe", "weixin.exe"):
            titles.append(title)
    info.window_titles = sorted(set(titles))[:10]

    # L2 is intentionally conservative. WeChat does not expose a stable
    # official desktop unread API; titles/taskbar hints vary by version.
    unread_candidates = [
        t for t in info.window_titles
        if "[" in t or "(" in t or "\u6761" in t or "\u672a\u8bfb" in t
    ]
    info.unread_hint = unread_candidates[0] if unread_candidates else "unknown"
    return info


def probe_activitywatch(force: bool = False) -> ActivityWatchInfo:
    global _activitywatch_cache
    now = time.monotonic()
    checked_at = getattr(probe_activitywatch, "_checked_at", 0.0)
    if not force and _activitywatch_cache and now - checked_at < ACTIVITYWATCH_INTERVAL_SECONDS:
        return _activitywatch_cache

    aw = ActivityWatchInfo()
    try:
        with urllib.request.urlopen(f"{ACTIVITYWATCH_URL}/api/0/buckets/", timeout=0.25) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        aw.reachable = True
        aw.buckets = sorted(list(data.keys()))[:20] if isinstance(data, dict) else []
        if isinstance(data, dict):
            for bucket_id, meta in data.items():
                bucket_type = meta.get("type") if isinstance(meta, dict) else ""
                client = meta.get("client") if isinstance(meta, dict) else ""
                if not aw.window_bucket and (bucket_type == "currentwindow" or client == "aw-watcher-window"):
                    aw.window_bucket = bucket_id
                if not aw.afk_bucket and (bucket_type == "afkstatus" or client == "aw-watcher-afk"):
                    aw.afk_bucket = bucket_id
        if aw.window_bucket:
            aw.latest_window = fetch_activitywatch_window(aw.window_bucket)
            aw.recent_windows = fetch_activitywatch_recent_windows(aw.window_bucket)
            aw.top_apps_30m, aw.window_observed_seconds_30m = summarize_app_usage(aw.recent_windows)
        if aw.afk_bucket:
            aw.latest_afk = fetch_activitywatch_afk(aw.afk_bucket)
            aw.active_seconds_30m, aw.afk_seconds_30m = summarize_afk_usage(aw.afk_bucket)
    except urllib.error.URLError as exc:
        aw.error = str(exc.reason)
    except Exception as exc:
        aw.error = str(exc)
    _activitywatch_cache = aw
    probe_activitywatch._checked_at = now
    return aw


def fetch_activitywatch_events(
    bucket_id: str,
    limit: int = 1,
    start: str = "",
    timeout: float = 0.25,
) -> list[dict[str, Any]]:
    url = f"{ACTIVITYWATCH_URL}/api/0/buckets/{quote(bucket_id, safe='')}/events?limit={limit}"
    if start:
        url += f"&start={quote(start, safe='')}"
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    return []


def activitywatch_lookback_start() -> str:
    start = datetime.now(timezone.utc) - timedelta(minutes=ACTIVITYWATCH_LOOKBACK_MINUTES)
    return start.strftime("%Y-%m-%dT%H:%M:%SZ")


def fetch_activitywatch_window(bucket_id: str) -> ActivityWatchWindow:
    events = fetch_activitywatch_events(bucket_id, limit=1)
    if not events:
        return ActivityWatchWindow(bucket=bucket_id)
    event = events[0]
    data = event.get("data") if isinstance(event.get("data"), dict) else {}
    return ActivityWatchWindow(
        bucket=bucket_id,
        app=str(data.get("app", "")),
        title=str(data.get("title", "")),
        timestamp=str(event.get("timestamp", "")),
        duration=float(event.get("duration", 0.0) or 0.0),
    )


def event_to_activitywatch_window(bucket_id: str, event: dict[str, Any]) -> ActivityWatchWindow:
    data = event.get("data") if isinstance(event.get("data"), dict) else {}
    return ActivityWatchWindow(
        bucket=bucket_id,
        app=str(data.get("app", "")),
        title=str(data.get("title", "")),
        timestamp=str(event.get("timestamp", "")),
        duration=float(event.get("duration", 0.0) or 0.0),
    )


def fetch_activitywatch_recent_windows(bucket_id: str) -> list[ActivityWatchWindow]:
    events = fetch_activitywatch_events(
        bucket_id,
        limit=300,
        start=activitywatch_lookback_start(),
        timeout=1.0,
    )
    return [event_to_activitywatch_window(bucket_id, event) for event in events][:50]


def summarize_app_usage(windows: list[ActivityWatchWindow]) -> tuple[list[ActivityWatchAppUsage], float]:
    totals: dict[str, ActivityWatchAppUsage] = {}
    total_seconds = 0.0
    for window in windows:
        app = window.app or "(unknown)"
        seconds = max(0.0, float(window.duration or 0.0))
        item = totals.setdefault(app, ActivityWatchAppUsage(app=app))
        item.seconds += seconds
        item.events += 1
        total_seconds += seconds
    top = sorted(totals.values(), key=lambda item: item.seconds, reverse=True)[:8]
    for item in top:
        item.percent = round((item.seconds / total_seconds) * 100, 1) if total_seconds > 0 else 0.0
        item.seconds = round(item.seconds, 1)
    return top, round(total_seconds, 1)


def fetch_activitywatch_afk(bucket_id: str) -> ActivityWatchAfk:
    events = fetch_activitywatch_events(bucket_id, limit=1)
    if not events:
        return ActivityWatchAfk(bucket=bucket_id)
    event = events[0]
    data = event.get("data") if isinstance(event.get("data"), dict) else {}
    return ActivityWatchAfk(
        bucket=bucket_id,
        status=str(data.get("status", "")),
        timestamp=str(event.get("timestamp", "")),
        duration=float(event.get("duration", 0.0) or 0.0),
    )


def summarize_afk_usage(bucket_id: str) -> tuple[float, float]:
    events = fetch_activitywatch_events(
        bucket_id,
        limit=300,
        start=activitywatch_lookback_start(),
        timeout=1.0,
    )
    active_seconds = 0.0
    afk_seconds = 0.0
    for event in events:
        data = event.get("data") if isinstance(event.get("data"), dict) else {}
        duration = max(0.0, float(event.get("duration", 0.0) or 0.0))
        if data.get("status") == "afk":
            afk_seconds += duration
        elif data.get("status") == "not-afk":
            active_seconds += duration
    return round(active_seconds, 1), round(afk_seconds, 1)


LOW_VALUE_WINDOW_APPS = {
    "explorer.exe",
    "shellexperiencehost.exe",
    "searchhost.exe",
    "startmenuexperiencehost.exe",
    "textinputhost.exe",
    "applicationframehost.exe",
}

LOW_VALUE_WINDOW_TITLES = {
    "",
    "program manager",
    "windows input experience",
}


def is_low_value_window(app: str, title: str) -> bool:
    app_l = (app or "").lower()
    title_l = (title or "").strip().lower()
    if not app_l and not title_l:
        return True
    if title_l in LOW_VALUE_WINDOW_TITLES:
        return True
    return app_l in LOW_VALUE_WINDOW_APPS and title_l in LOW_VALUE_WINDOW_TITLES


def select_effective_window(active: WindowInfo, aw: ActivityWatchInfo) -> EffectiveWindow:
    """Use ActivityWatch as a fallback when Windows reports a shell/no-value window."""
    active_app = active.process_name or ""
    active_title = active.title or ""
    if not is_low_value_window(active_app, active_title):
        duration = max(0.0, float(active.foreground_duration or 0.0))
        if (
            aw.latest_window.app.lower() == active_app.lower()
            and (not active_title or aw.latest_window.title == active_title)
        ):
            duration = max(duration, float(aw.latest_window.duration or 0.0))
        return EffectiveWindow(
            app=active_app,
            title=active_title,
            duration=duration,
            source="native",
            reason="native_foreground_with_activitywatch_duration" if duration > float(active.foreground_duration or 0.0) else "native_foreground",
        )

    candidates: list[tuple[str, ActivityWatchWindow]] = []
    if aw.latest_window.app or aw.latest_window.title:
        candidates.append(("activitywatch_latest", aw.latest_window))
    candidates.extend(("activitywatch_recent", item) for item in aw.recent_windows[:8])
    for source, item in candidates:
        if item.app or item.title:
            if not is_low_value_window(item.app, item.title):
                return EffectiveWindow(
                    app=item.app,
                    title=item.title,
                    duration=max(0.0, float(item.duration or 0.0)),
                    source=source,
                    reason=f"native_low_value:{active_app}/{active_title}",
                )

    return EffectiveWindow(
        app=active_app,
        title=active_title,
        duration=max(0.0, float(active.foreground_duration or 0.0)),
        source="native_low_value",
        reason="no_activitywatch_fallback",
    )


def derive_context(active: WindowInfo, wechat: WeChatInfo, aw: ActivityWatchInfo) -> DerivedContext:
    effective = select_effective_window(active, aw)
    app = effective.app.lower()
    title = effective.title.lower()
    if active.idle_seconds >= 300:
        return DerivedContext("away", "quiet", "keyboard/mouse idle >= 5min")
    if any(name in app for name in ("codex.exe", "code.exe", "cursor.exe", "devenv.exe", "pycharm64.exe", "webstorm64.exe")):
        return DerivedContext("coding", "quiet", "developer tool foreground")
    if any(name in app for name in ("chrome.exe", "msedge.exe", "firefox.exe")):
        if any(word in title for word in ("github", "docs", "stackoverflow", "localhost", "127.0.0.1")):
            return DerivedContext("research", "quiet", "work-like browser title")
        return DerivedContext("browser", "allow_speak", "browser foreground")
    if any(name in app for name in ("douyin.exe", "bilibili", "vlc", "potplayer", "mpv")) or any(
        word in title for word in ("抖音", "bilibili", "youtube", "视频", "播放")
    ):
        return DerivedContext("leisure", "quiet", "leisure/video foreground")
    return DerivedContext("unknown", "allow_speak", "no specific rule matched")


def collect_state() -> AgentState:
    active = get_foreground_window()
    input_activity = get_input_activity()
    session_started_at, session_duration = update_session_timing(input_activity)
    device_activity, signal_quality = get_device_activity()
    wechat = get_wechat_info(active)
    aw = probe_activitywatch()
    system = get_system_info()
    effective = select_effective_window(active, aw)
    if aw.latest_window.app or aw.latest_window.title:
        if effective.source.startswith("activitywatch"):
            signal_quality.foreground = "available:fused_activitywatch"
        else:
            signal_quality.foreground = "available:activitywatch" if not active.process_name and not active.title else "available"
    elif not active.process_name and not active.title:
        signal_quality.foreground = "unavailable"
    derived = derive_context(active, wechat, aw)
    return AgentState(
        collected_at=time.time(),
        session_started_at=session_started_at,
        session_duration=session_duration,
        active_window=active,
        input_activity=input_activity,
        device_activity=device_activity,
        signal_quality=signal_quality,
        wechat=wechat,
        activitywatch=aw,
        system=system,
        derived=derived,
    )


def sampler_loop() -> None:
    global _latest_state
    while True:
        try:
            state = collect_state()
            with _state_lock:
                _latest_state = state
        except Exception as exc:
            fallback = AgentState(
                collected_at=time.time(),
                activitywatch=_activitywatch_cache or ActivityWatchInfo(),
                derived=DerivedContext("unknown", "allow_speak", f"sampler error: {exc}"),
            )
            with _state_lock:
                _latest_state = fallback
        time.sleep(SAMPLE_INTERVAL_SECONDS)


def get_cached_state() -> AgentState:
    with _state_lock:
        state = _latest_state
    if state:
        return state
    return collect_state()


def build_backend_payload(state: AgentState) -> dict[str, Any]:
    aw = state.activitywatch
    effective = select_effective_window(state.active_window, aw)
    current_app = effective.app
    current_title = effective.title
    foreground_duration = effective.duration
    return {
        "type": "desktop_context",
        "user_id": "default",
        "robot_id": "default",
        "hostname": state.hostname,
        "timestamp": state.collected_at,
        "session_started_at": state.session_started_at,
        "session_duration": state.session_duration,
        "desktop_context": state.derived.activity,
        "attention_hint": state.derived.attention_hint,
        "reason": state.derived.reason,
        "current_app": current_app,
        "current_title": current_title,
        "foreground_duration": foreground_duration,
        "foreground_source": effective.source,
        "foreground_fallback_reason": effective.reason,
        "raw_foreground": asdict(state.active_window),
        "input_activity": asdict(state.input_activity),
        "device_activity": asdict(state.device_activity),
        "signal_quality": asdict(state.signal_quality),
        "afk_status": aw.latest_afk.status or "unknown",
        "active_seconds_30m": aw.active_seconds_30m,
        "active_seconds_window": aw.active_seconds_30m,
        "activitywatch_lookback_minutes": aw.lookback_minutes,
        "afk_seconds_30m": aw.afk_seconds_30m,
        "top_apps_30m": [asdict(item) for item in aw.top_apps_30m],
        "wechat": asdict(state.wechat),
        "system": asdict(state.system),
        "activitywatch": {
            "reachable": aw.reachable,
            "window_bucket": aw.window_bucket,
            "afk_bucket": aw.afk_bucket,
            "latest_window": asdict(aw.latest_window),
            "latest_afk": asdict(aw.latest_afk),
            "lookback_minutes": aw.lookback_minutes,
        },
    }


def post_backend_payload(payload: dict[str, Any]) -> dict[str, Any]:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        BACKEND_DESKTOP_CONTEXT_URL,
        data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=3.0) as resp:
        response = json.loads(resp.read().decode("utf-8"))
    return response if isinstance(response, dict) else {"ok": True, "response": response}


def _backend_headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json; charset=utf-8"}
    if BACKEND_DEBUG_TOKEN:
        headers["X-Debug-Token"] = BACKEND_DEBUG_TOKEN
    return headers


def post_backend_context(state: AgentState) -> dict[str, Any]:
    return post_backend_payload(build_backend_payload(state))


def post_debug_robot_action(text: str, emotion: str = "happy", action: str = "nod") -> dict[str, Any]:
    url = BACKEND_DESKTOP_CONTEXT_URL.rsplit("/", 1)[0] + "/debug/robot-action"
    body = json.dumps({
        "text": text,
        "emotion": emotion,
        "action": action,
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers=_backend_headers(),
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=5.0) as resp:
        response = json.loads(resp.read().decode("utf-8"))
    return response if isinstance(response, dict) else {"ok": True, "response": response}


def build_test_payload(scenario: str, state: AgentState, timestamp: float | None = None) -> dict[str, Any]:
    payload = build_backend_payload(state)
    now = time.time() if timestamp is None else timestamp
    payload["timestamp"] = now
    payload["test_scenario"] = scenario
    if scenario == "current":
        return payload
    payload["signal_quality"] = {
        "keyboard": "available",
        "mouse": "available",
        "scroll": "available",
        "foreground": "available",
        "camera": "available",
        "mic": "available",
        "audio": "available",
    }
    payload["device_activity"] = {"camera_active": False, "mic_active": False, "audio_playing": False}
    payload["input_activity"] = {
        "keys_last_60s": 0,
        "mouse_clicks_last_60s": 0,
        "recent_mouse_clicks_60s": 0,
        "scroll_events_last_60s": 0,
        "idle_seconds": 0,
    }
    if scenario == "deep_coding":
        payload.update({
            "desktop_context": "coding",
            "attention_hint": "quiet",
            "reason": "manual test: deep coding with real-signal-shaped payload",
            "current_app": "Code.exe",
            "current_title": "server.py - coding",
            "foreground_duration": 45 * 60 + 5,
            "session_duration": 50 * 60,
            "input_activity": {"keys_last_60s": 30, "mouse_clicks_last_60s": 2, "recent_mouse_clicks_60s": 2, "scroll_events_last_60s": 0, "idle_seconds": 0},
        })
    elif scenario == "meeting_enter":
        payload.update({
            "desktop_context": "work",
            "attention_hint": "do_not_disturb",
            "reason": "manual test: meeting device active",
            "current_app": "Teams.exe",
            "current_title": "Teams Meeting - 正在通话",
            "foreground_duration": 90,
            "device_activity": {"camera_active": False, "mic_active": True, "audio_playing": False},
        })
    elif scenario == "meeting_exit":
        payload.update({
            "desktop_context": "work",
            "attention_hint": "allow_speak",
            "reason": "manual test: meeting devices clear",
            "current_app": "Teams.exe",
            "current_title": "Teams",
            "foreground_duration": 120,
            "device_activity": {"camera_active": False, "mic_active": False, "audio_playing": False},
        })
    elif scenario == "reading_thinking":
        payload.update({
            "desktop_context": "research",
            "reason": "manual test: reading/thinking",
            "current_app": "msedge.exe",
            "current_title": "docs",
            "foreground_duration": 31 * 60,
            "input_activity": {"keys_last_60s": 1, "mouse_clicks_last_60s": 1, "recent_mouse_clicks_60s": 1, "scroll_events_last_60s": 3, "idle_seconds": 4},
        })
    elif scenario == "fatigue":
        payload.update({
            "current_app": "Code.exe",
            "current_title": "repo",
            "desktop_context": "coding",
            "foreground_duration": 20 * 60,
            "session_duration": 95 * 60,
            "input_activity": {"keys_last_60s": 1, "mouse_clicks_last_60s": 0, "recent_mouse_clicks_60s": 0, "scroll_events_last_60s": 0, "idle_seconds": 2},
        })
    elif scenario == "late_night_work":
        payload.update({
            "desktop_context": "coding",
            "current_app": "Code.exe",
            "current_title": "late night work",
            "foreground_duration": 20 * 60,
            "session_duration": 40 * 60,
            "input_activity": {"keys_last_60s": 5, "mouse_clicks_last_60s": 1, "recent_mouse_clicks_60s": 1, "scroll_events_last_60s": 0, "idle_seconds": 1},
        })
    elif scenario == "video_leisure":
        payload.update({
            "desktop_context": "browser",
            "current_app": "chrome.exe",
            "current_title": "video playback",
            "foreground_duration": 21 * 60,
            "session_duration": 30 * 60,
            "device_activity": {"camera_active": False, "mic_active": False, "audio_playing": True},
            "input_activity": {"keys_last_60s": 0, "mouse_clicks_last_60s": 0, "recent_mouse_clicks_60s": 0, "scroll_events_last_60s": 0, "idle_seconds": 60},
        })
    elif scenario == "away":
        payload.update({
            "desktop_context": "away",
            "attention_hint": "quiet",
            "reason": "manual test: away",
            "current_app": "",
            "current_title": "",
            "afk_status": "afk",
            "input_activity": {"keys_last_60s": 0, "mouse_clicks_last_60s": 0, "recent_mouse_clicks_60s": 0, "scroll_events_last_60s": 0, "idle_seconds": 360},
        })
    elif scenario in {"return", "return_short", "return_long"}:
        payload.update({
            "desktop_context": "unknown",
            "attention_hint": "allow_speak",
            "reason": "manual test: return",
            "current_app": "Code.exe",
            "current_title": "Codex",
            "input_activity": {"keys_last_60s": 1, "mouse_clicks_last_60s": 1, "recent_mouse_clicks_60s": 1, "scroll_events_last_60s": 0, "idle_seconds": 1},
        })
    return payload


def run_test_scenario(scenario: str) -> dict[str, Any]:
    state = get_cached_state()
    now = time.time()
    if scenario in {"return_short", "return_long"}:
        away_seconds = 6 * 60 if scenario == "return_short" else 121 * 60
        away = build_test_payload("away", state, timestamp=now - away_seconds)
        away_result = post_backend_payload(away)
        time.sleep(0.2)
        returned = build_test_payload(scenario, state, timestamp=now)
        return_result = post_backend_payload(returned)
        return {"ok": True, "scenario": scenario, "steps": [away_result, return_result]}
    if scenario == "force_welcome":
        return post_debug_robot_action("欢迎回来", "happy", "nod")
    payload = build_test_payload(scenario, state, timestamp=now)
    result = post_backend_payload(payload)
    return {"ok": True, "scenario": scenario, "response": result}


def backend_post_loop() -> None:
    global _last_post_result
    if not BACKEND_POST_ENABLED:
        return
    while True:
        started_at = time.time()
        try:
            state = get_cached_state()
            response = post_backend_context(state)
            result = {
                "enabled": True,
                "url": BACKEND_DESKTOP_CONTEXT_URL,
                "ok": bool(response.get("ok", True)),
                "sent_at": time.time(),
                "response": response,
                "error": "",
            }
        except Exception as exc:
            result = {
                "enabled": True,
                "url": BACKEND_DESKTOP_CONTEXT_URL,
                "ok": False,
                "sent_at": time.time(),
                "error": str(exc),
            }
        with _post_lock:
            _last_post_result = result
        elapsed = time.time() - started_at
        time.sleep(max(1.0, BACKEND_POST_INTERVAL_SECONDS - elapsed))


def get_last_post_result() -> dict[str, Any]:
    with _post_lock:
        return dict(_last_post_result)


def fetch_backend_status() -> dict[str, Any]:
    url = BACKEND_DESKTOP_CONTEXT_URL.rsplit("/", 1)[0] + "/desktop-context/status"
    try:
        req = urllib.request.Request(url, headers=_backend_headers(), method="GET")
        with urllib.request.urlopen(req, timeout=4.0) as resp:
            response = json.loads(resp.read().decode("utf-8"))
        return response if isinstance(response, dict) else {"ok": True, "response": response}
    except Exception as exc:
        return {"ok": False, "error": str(exc), "url": url}


def html_page() -> bytes:
    return PAGE.encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        if self.path == "/" or self.path == "/index.html":
            self._send(200, html_page(), "text/html; charset=utf-8")
            return
        if self.path == "/api/state":
            state = asdict(get_cached_state())
            state["backend_post"] = get_last_post_result()
            self._send(200, json.dumps(state, ensure_ascii=False, indent=2).encode("utf-8"), "application/json; charset=utf-8")
            return
        if self.path == "/api/backend-status":
            status = fetch_backend_status()
            self._send(200, json.dumps(status, ensure_ascii=False, indent=2).encode("utf-8"), "application/json; charset=utf-8")
            return
        self._send(404, b"not found", "text/plain")

    def do_POST(self) -> None:
        if self.path == "/api/test-event":
            try:
                raw = self.rfile.read(int(self.headers.get("Content-Length", "0") or 0))
                body = json.loads(raw.decode("utf-8")) if raw else {}
                scenario = str(body.get("scenario") or "current")
                result = run_test_scenario(scenario)
                self._send(200, json.dumps(result, ensure_ascii=False, indent=2).encode("utf-8"), "application/json; charset=utf-8")
            except Exception as exc:
                self._send(500, json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2).encode("utf-8"), "application/json; charset=utf-8")
            return
        self._send(404, b"not found", "text/plain")

    def log_message(self, fmt: str, *args: Any) -> None:
        print("[%s] %s" % (self.log_date_time_string(), fmt % args))


PAGE = r"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Desktop Rhythm Agent</title>
  <style>
    body { margin: 0; font-family: "Segoe UI", Arial, sans-serif; background: #101418; color: #e7edf3; }
    header { padding: 18px 22px; border-bottom: 1px solid #2a333d; background: #151b21; }
    h1 { margin: 0; font-size: 20px; font-weight: 650; }
    .tagline { margin: 7px 0 0; color: #a7b7c6; font-size: 13px; max-width: 960px; }
    main { padding: 18px 22px; display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 14px; }
    section { border: 1px solid #2a333d; border-radius: 8px; padding: 14px; background: #151b21; }
    h2 { margin: 0 0 10px; font-size: 15px; color: #9ecbff; }
    h3 { margin: 0 0 6px; font-size: 13px; color: #dbe8f3; }
    dl { margin: 0; display: grid; grid-template-columns: 120px 1fr; gap: 8px 10px; font-size: 14px; }
    dt { color: #91a2b2; }
    dd { margin: 0; word-break: break-word; }
    .ok { color: #8ee99a; }
    .warn { color: #ffd166; }
    .bad { color: #ff8b8b; }
    .wide { grid-column: 1 / -1; }
    pre { white-space: pre-wrap; margin: 0; font-size: 12px; color: #c8d4df; }
    button { background: #2383e2; color: white; border: 0; border-radius: 6px; padding: 8px 10px; cursor: pointer; }
    button:hover { background: #3291f0; }
    .buttons { display: flex; flex-wrap: wrap; gap: 8px; }
    .buttons button { background: #2f6f8f; }
    .buttons button.primary { background: #2383e2; }
    .level { display: inline-block; min-width: 34px; padding: 2px 7px; border-radius: 999px; font-weight: 700; text-align: center; }
    .tier { display: inline-block; min-width: 54px; padding: 2px 7px; border-radius: 999px; font-weight: 700; text-align: center; }
    .tier-quiet { background: #26313c; color: #91a2b2; }
    .tier-subtle { background: #173b2a; color: #8ee99a; }
    .tier-subtitle { background: #203a52; color: #9fd2ff; }
    .tier-speak { background: #4a2222; color: #ffb0b0; }
    .hero { grid-column: 1 / -1; display: grid; grid-template-columns: minmax(260px, 1.2fr) minmax(260px, 1fr); gap: 14px; }
    .hero p { margin: 0; color: #a7b7c6; line-height: 1.55; }
    .pill-row { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
    .pill { border: 1px solid #344454; border-radius: 999px; padding: 4px 9px; color: #c9d7e4; font-size: 12px; }
    .signal-grid, .scenario-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px; }
    .mini { border: 1px solid #2a333d; border-radius: 7px; padding: 10px; background: #111820; }
    .mini p { margin: 4px 0 0; color: #9fb1c1; font-size: 12px; line-height: 1.45; }
    .status-line { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    .event-list { display: grid; gap: 8px; }
    .event { border: 1px solid #2a333d; border-radius: 7px; padding: 9px; background: #111820; }
    .event strong { display: block; font-size: 13px; color: #dbe8f3; }
    .event span { display: block; margin-top: 4px; color: #9fb1c1; font-size: 12px; }
    @media (max-width: 760px) { .hero { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
  <header>
    <h1>Desktop Rhythm Agent</h1>
    <p class="tagline">不依赖摄像头，通过桌面行为理解用户节奏的具身 AI 桌面伴侣。这个面板用于展示真实信号、后端判断和机器人低打扰反馈链路。</p>
  </header>
  <main>
    <section class="hero">
      <div>
        <h2>Product Demo</h2>
        <p>目标：把机器人从被动问答升级为能理解工作节奏的桌面伙伴。系统只使用真实可采集信号，默认视觉优先，语音克制，会议和专注任务中不主动打扰。</p>
        <div class="pill-row">
          <span class="pill">Real signals first</span>
          <span class="pill">quiet / subtle / subtitle / speak</span>
          <span class="pill">ActivityWatch compatible</span>
          <span class="pill">WebSocket robot feedback</span>
        </div>
      </div>
      <div>
        <h2>Demo Checklist</h2>
        <dl>
          <dt>3 min pitch</dt><dd>定位、用户痛点、技术边界、差异化</dd>
          <dt>5 min demo</dt><dd>dashboard + 两个主动交互场景</dd>
          <dt>Proof</dt><dd>真实信号、判断证据、最近事件、自测报告</dd>
        </dl>
      </div>
    </section>
    <section class="wide">
      <h2>Current Robot Understanding</h2>
      <div class="status-line">
        <span id="understanding-state" class="pill">state: -</span>
        <span id="understanding-tier" class="pill">tier: -</span>
        <span id="understanding-scene" class="pill">scene: -</span>
        <span id="understanding-action" class="pill">action: -</span>
      </div>
      <dl style="margin-top: 12px;">
        <dt>Why</dt><dd id="understanding-why">-</dd>
        <dt>Evidence</dt><dd id="understanding-evidence">-</dd>
        <dt>Robot output</dt><dd id="understanding-output">-</dd>
      </dl>
    </section>
    <section>
      <h2>Agent</h2>
      <dl>
        <dt>Status</dt><dd id="agent">loading</dd>
        <dt>Heartbeat</dt><dd id="heartbeat">-</dd>
        <dt>Sample rate</dt><dd id="sample-rate">-</dd>
        <dt>Backend</dt><dd id="backend">-</dd>
        <dt>Host</dt><dd id="host">-</dd>
      </dl>
    </section>
    <section>
      <h2>Active Window</h2>
      <dl>
        <dt>App</dt><dd id="app">-</dd>
        <dt>Title</dt><dd id="title">-</dd>
        <dt>Idle</dt><dd id="idle">-</dd>
      </dl>
    </section>
    <section>
      <h2>Real Signals</h2>
      <dl>
        <dt>Keys</dt><dd id="keys">-</dd>
        <dt>Clicks</dt><dd id="clicks">-</dd>
        <dt>Scroll</dt><dd id="scroll">-</dd>
        <dt>Foreground</dt><dd id="foreground-duration">-</dd>
        <dt>Session</dt><dd id="session-duration">-</dd>
      </dl>
    </section>
    <section>
      <h2>Devices</h2>
      <dl>
        <dt>Camera</dt><dd id="camera">-</dd>
        <dt>Mic</dt><dd id="mic">-</dd>
        <dt>Audio</dt><dd id="audio">-</dd>
        <dt>Quality</dt><dd id="quality">-</dd>
      </dl>
    </section>
    <section>
      <h2>ActivityWatch</h2>
      <dl>
        <dt>Reachable</dt><dd id="aw-reachable">-</dd>
        <dt>Window</dt><dd id="aw-window">-</dd>
        <dt>AFK</dt><dd id="aw-afk">-</dd>
        <dt>Lookback apps</dt><dd id="aw-top-apps">-</dd>
        <dt>Lookback active</dt><dd id="aw-active">-</dd>
        <dt>Buckets</dt><dd id="aw-buckets">-</dd>
        <dt>Error</dt><dd id="aw-error">-</dd>
      </dl>
    </section>
    <section>
      <h2>Derived Context</h2>
      <dl>
        <dt>Activity</dt><dd id="activity">-</dd>
        <dt>Attention</dt><dd id="attention">-</dd>
        <dt>Reason</dt><dd id="reason">-</dd>
        <dt>Mouse clicks</dt><dd id="mouse-clicks">-</dd>
      </dl>
    </section>
    <section class="wide">
      <h2>Proactive Interaction</h2>
      <dl>
        <dt>User state</dt><dd id="user-state">-</dd>
        <dt>Rhythm event</dt><dd id="rhythm-event">-</dd>
        <dt>Tier</dt><dd id="interaction-tier">-</dd>
        <dt>Scene</dt><dd id="interaction-scene">-</dd>
        <dt>Delivery</dt><dd id="interaction-delivery">-</dd>
        <dt>Reason</dt><dd id="interaction-reason">-</dd>
        <dt>Policy reason</dt><dd id="policy-reason">-</dd>
        <dt>Suppression</dt><dd id="policy-suppression">-</dd>
        <dt>Downgrade</dt><dd id="policy-downgrade">-</dd>
        <dt>Cooldown</dt><dd id="policy-cooldown">-</dd>
        <dt>Budget</dt><dd id="policy-budget">-</dd>
        <dt>Generated</dt><dd id="policy-generated">-</dd>
        <dt>Preferences</dt><dd id="policy-preferences">-</dd>
        <dt>Last backend intent</dt><dd id="backend-intent">-</dd>
        <dt>Last response</dt><dd id="last-test">-</dd>
      </dl>
      <div class="buttons" style="margin-top: 12px;">
        <button class="primary" onclick="sendTest('current')">Send Current Context</button>
        <button onclick="sendTest('meeting_enter')">Manual Meeting Enter</button>
        <button onclick="sendTest('meeting_exit')">Manual Meeting Exit</button>
        <button onclick="sendTest('deep_coding')">Manual Deep Coding</button>
        <button onclick="sendTest('reading_thinking')">Manual Reading</button>
        <button onclick="sendTest('fatigue')">Manual Fatigue</button>
        <button onclick="sendTest('late_night_work')">Manual Late Night</button>
        <button onclick="sendTest('return_short')">Manual Short Return</button>
        <button onclick="sendTest('return_long')">Manual Long Return</button>
        <button onclick="sendTest('video_leisure')">Manual Video State</button>
        <button class="primary" onclick="sendTest('force_welcome')">Force Say Welcome</button>
      </div>
      <p class="warn">Manual buttons are explicit tests; real policy still requires real collected signals.</p>
    </section>
    <section class="wide">
      <h2>Five Scenario Validation</h2>
      <div class="scenario-grid">
        <div class="mini">
          <h3>1. 离开回来</h3>
          <p>真实键鼠静默 >= 5 分钟后恢复输入；返回后优先 subtitle 摘要，必要时再升级。</p>
          <p id="scenario-return">status: -</p>
        </div>
        <div class="mini">
          <h3>2. 深度工作</h3>
          <p>生产性窗口 + 键盘活跃 + 累计工作时长；提醒要短、轻、不说教。</p>
          <p id="scenario-deep-work">status: -</p>
        </div>
        <div class="mini">
          <h3>3. 会议安静</h3>
          <p>会议软件 + 麦克风/摄像头真实 active 持续 60 秒；只做静默动作。</p>
          <p id="scenario-meeting">status: -</p>
        </div>
        <div class="mini">
          <h3>4. 阅读思考</h3>
          <p>低键盘 + 滚动/点击 + 文档/浏览器；低频陪伴，不语音打扰。</p>
          <p id="scenario-reading">status: -</p>
        </div>
        <div class="mini">
          <h3>5. 计时提醒</h3>
          <p>用户明确创建专注/提醒任务；到点优先级最高，不被主动交互覆盖。</p>
          <p id="scenario-timer">status: backend task guard</p>
        </div>
      </div>
    </section>
    <section class="wide">
      <h2>Recent Robot Events</h2>
      <div id="events" class="event-list">loading</div>
    </section>
    <section class="wide">
      <h2>Raw JSON</h2>
      <pre id="raw"></pre>
    </section>
  </main>
  <script>
    async function refresh() {
      const [stateRes, backendRes] = await Promise.all([
        fetch('/api/state', { cache: 'no-store' }),
        fetch('/api/backend-status', { cache: 'no-store' })
      ]);
      const data = await stateRes.json();
      const backendStatus = await backendRes.json();
      const age = Math.max(0, Math.round(Date.now() / 1000 - data.collected_at));
      set('agent', data.agent, 'ok');
      set('heartbeat', age + 's ago');
      set('sample-rate', data.sample_interval_seconds + 's');
      set('backend', (data.backend_post && data.backend_post.ok ? 'posted' : 'not posted') +
        (data.backend_post && data.backend_post.error ? '\n' + data.backend_post.error : ''),
        data.backend_post && data.backend_post.ok ? 'ok' : 'warn');
      set('host', data.hostname);
      set('app', data.active_window.process_name || '(unknown)');
      set('title', data.active_window.title || '(empty)');
      set('idle', data.active_window.idle_seconds + 's');
      set('keys', String((data.input_activity && data.input_activity.keys_last_60s) || 0) + ' / 60s');
      set('clicks', String((data.input_activity && data.input_activity.mouse_clicks_last_60s) || 0) + ' / 60s');
      set('scroll', String((data.input_activity && data.input_activity.scroll_events_last_60s) || 0) + ' / 60s');
      set('foreground-duration', Math.round(data.active_window.foreground_duration || 0) + 's');
      set('session-duration', Math.round(data.session_duration || 0) + 's');
      set('camera', JSON.stringify({
        active: data.device_activity && data.device_activity.camera_active,
        sources: data.device_activity && data.device_activity.active_camera_sources
      }, null, 2), data.device_activity && data.device_activity.camera_active ? 'ok' : 'warn');
      set('mic', JSON.stringify({
        active: data.device_activity && data.device_activity.mic_active,
        sources: data.device_activity && data.device_activity.active_mic_sources
      }, null, 2), data.device_activity && data.device_activity.mic_active ? 'ok' : 'warn');
      set('audio', JSON.stringify({
        playing: data.device_activity && data.device_activity.audio_playing,
        sessions: data.device_activity && data.device_activity.active_audio_sessions
      }, null, 2), data.device_activity && data.device_activity.audio_playing ? 'ok' : 'warn');
      set('quality', JSON.stringify(data.signal_quality || {}, null, 2));
      set('aw-reachable', String(data.activitywatch.reachable), data.activitywatch.reachable ? 'ok' : 'warn');
      set('aw-window', [
        data.activitywatch.latest_window.app || '(unknown)',
        data.activitywatch.latest_window.title || '(empty)'
      ].join('\n'));
      set('aw-afk', data.activitywatch.latest_afk.status || '(unknown)');
      set('aw-top-apps', data.activitywatch.top_apps_30m.map(item =>
        item.app + ' ' + Math.round(item.seconds) + 's ' + item.percent + '%'
      ).join('\n') || '(none)');
      set('aw-active', Math.round(data.activitywatch.active_seconds_30m) + 's active / ' +
        Math.round(data.activitywatch.afk_seconds_30m) + 's afk / ' +
        data.activitywatch.lookback_minutes + 'm window');
      set('aw-buckets', data.activitywatch.buckets.join('\n') || '(none)');
      set('aw-error', data.activitywatch.error || '-');
      set('activity', data.derived.activity);
      set('attention', data.derived.attention_hint);
      set('reason', data.derived.reason);
      set('mouse-clicks', data.input_activity ? String(data.input_activity.recent_mouse_clicks_60s || 0) + ' / 60s' : '-');
      const intent = data.backend_post && data.backend_post.response
        ? (data.backend_post.response.intent || null)
        : null;
      renderIntent(intent, data.backend_post && data.backend_post.response
        ? data.backend_post.response.user_state
        : null, backendStatus);
      renderUnderstanding(intent, data.backend_post && data.backend_post.response
        ? data.backend_post.response.user_state
        : null);
      renderScenarioCards(data, intent, data.backend_post && data.backend_post.response
        ? data.backend_post.response.user_state
        : null);
      renderEvents(backendStatus);
      set('backend-intent', intent ? JSON.stringify(intent, null, 2) : '-');
      document.getElementById('raw').textContent = JSON.stringify({
        local_state: data,
        backend_status: backendStatus
      }, null, 2);
    }
    function renderUnderstanding(intent, userState) {
      const stateName = userState && userState.state ? userState.state : '-';
      const tier = intent && intent.interaction_tier ? intent.interaction_tier : '-';
      const scene = intent && intent.scene ? intent.scene : '-';
      const expression = intent && intent.expression ? intent.expression : '-';
      const action = intent && intent.action ? intent.action : '-';
      document.getElementById('understanding-state').textContent = 'state: ' + stateName;
      document.getElementById('understanding-tier').textContent = 'tier: ' + tier;
      document.getElementById('understanding-scene').textContent = 'scene: ' + scene;
      document.getElementById('understanding-action').textContent = 'action: ' + expression + ' / ' + action;
      set('understanding-why', (intent && intent.decision_reason) || (userState && userState.reason) || '-');
      set('understanding-evidence', compactEvidence(userState && userState.evidence ? userState.evidence : intent && intent.evidence));
      set('understanding-output', intent ? [
        intent.speak ? 'voice' : 'silent',
        intent.line ? ('line="' + intent.line + '"') : '',
        intent.delivery || '-',
        intent.sent_to !== undefined ? ('sent_to=' + intent.sent_to) : ''
      ].filter(Boolean).join(' / ') : '-');
    }
    function compactEvidence(evidence) {
      if (!evidence) return '-';
      const keys = [
        'keys_last_60s', 'mouse_clicks_last_60s', 'scroll_events_last_60s',
        'idle_seconds', 'foreground_duration', 'productive_duration',
        'mic_active', 'camera_active', 'audio_playing', 'current_app'
      ];
      return keys.filter(k => evidence[k] !== undefined)
        .map(k => k + '=' + evidence[k])
        .join(' / ') || JSON.stringify(evidence);
    }
    function renderScenarioCards(data, intent, userState) {
      const state = userState && userState.state ? userState.state : 'unknown';
      const input = data.input_activity || {};
      const device = data.device_activity || {};
      const aw = data.activitywatch || {};
      const app = ((aw.latest_window && aw.latest_window.app) || data.active_window.process_name || '').toLowerCase();
      const title = ((aw.latest_window && aw.latest_window.title) || data.active_window.title || '').toLowerCase();
      set('scenario-return', state.includes('return') || state === 'away'
        ? 'active: ' + state
        : 'waiting: idle=' + (input.idle_seconds || 0) + 's');
      set('scenario-deep-work', state === 'work_deepening' || state === 'work_stabilized' || state === 'deep_coding'
        ? 'active: ' + state
        : 'waiting: keys=' + (input.keys_last_60s || 0) + ', app=' + (app || 'unknown'));
      set('scenario-meeting', state.includes('meeting')
        ? 'active: ' + state
        : 'waiting: mic=' + device.mic_active + ', camera=' + device.camera_active);
      set('scenario-reading', state === 'reading_mode' || state === 'reading_thinking'
        ? 'active: ' + state
        : 'waiting: scroll=' + (input.scroll_events_last_60s || 0) + ', title=' + (title ? title.slice(0, 40) : 'unknown'));
      set('scenario-timer', 'status: use voice command such as "专注三分钟" to validate priority');
    }
    function renderEvents(status) {
      const el = document.getElementById('events');
      if (!status || !status.ok) {
        el.textContent = status && status.error ? status.error : 'backend status unavailable';
        return;
      }
      const events = Array.isArray(status.events) ? status.events.slice(-8).reverse() : [];
      if (!events.length) {
        el.textContent = 'No robot events yet after backend restart.';
        return;
      }
      el.innerHTML = events.map(event => {
        const title = [event.intent || '-', event.interaction_tier || '-', event.delivery || '-'].join(' / ');
        const detail = [
          event.user_state ? ('state=' + event.user_state) : '',
          event.scene ? ('scene=' + event.scene) : '',
          event.expression || event.action ? ('robot=' + (event.expression || '-') + '/' + (event.action || '-')) : '',
          event.decision_reason ? ('reason=' + event.decision_reason) : '',
          event.line ? ('line=' + event.line) : ''
        ].filter(Boolean).join(' | ');
        return '<div class="event"><strong>' + escapeHtml(title) + '</strong><span>' + escapeHtml(detail) + '</span></div>';
      }).join('');
    }
    function escapeHtml(text) {
      return String(text).replace(/[&<>"']/g, ch => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
      }[ch]));
    }
    function renderIntent(intent, userState, status) {
      if (!intent) {
        set('user-state', userState ? JSON.stringify(userState, null, 2) : '-');
        set('rhythm-event', userState && userState.rhythm_event ? userState.rhythm_event : '-');
        set('interaction-tier', '-');
        set('interaction-scene', '-');
        set('interaction-delivery', '-');
        set('interaction-reason', '-');
        set('policy-reason', '-');
        set('policy-suppression', '-');
        set('policy-downgrade', '-');
        set('policy-cooldown', '-');
        set('policy-budget', '-');
        set('policy-generated', '-');
        set('policy-preferences', '-');
        return;
      }
      set('user-state', userState ? JSON.stringify(userState, null, 2) : (intent.user_state || '-'));
      set('rhythm-event', userState && userState.rhythm_event ? userState.rhythm_event : (intent.user_state || '-'));
      const tier = intent.interaction_tier || '-';
      const tierEl = document.getElementById('interaction-tier');
      tierEl.innerHTML = tier === '-'
        ? '-'
        : '<span class="tier tier-' + tier + '">' + tier + '</span>';
      set('interaction-scene', intent.scene || '-');
      set('interaction-delivery', [
        intent.delivery || '-',
        intent.speak ? 'speech' : 'silent',
        intent.sent_to !== undefined ? ('sent_to=' + intent.sent_to) : ''
      ].filter(Boolean).join(' / '));
      set('interaction-reason', intent.decision_reason || '-');
      const policy = intent.policy || {};
      set('policy-reason', policy.reason || intent.decision_reason || '-');
      set('policy-suppression', policy.suppression_reason || intent.suppression_reason || '-',
        (policy.suppression_reason || intent.suppression_reason) ? 'warn' : '');
      set('policy-downgrade', policy.downgrade_reason || intent.downgrade_reason || '-',
        (policy.downgrade_reason || intent.downgrade_reason) ? 'warn' : '');
      const cooldown = policy.cooldown_remaining_seconds !== undefined
        ? policy.cooldown_remaining_seconds
        : intent.cooldown_remaining_seconds;
      set('policy-cooldown', cooldown !== undefined ? (cooldown + 's') : '-',
        cooldown > 0 ? 'warn' : '');
      set('policy-budget', formatBudget(policy.budget || intent.policy_budget));
      set('policy-generated', [
        (policy.generated_line || intent.generated_line) ? 'yes' : 'no',
        policy.generation_reason || ''
      ].filter(Boolean).join(' / '));
      set('policy-preferences', formatPreferences(status && status.preferences));
    }
    function formatPreferences(preferences) {
      if (!preferences) return '-';
      const scenes = preferences.scene_preferences || {};
      const entries = Object.keys(scenes).slice(-4).map(scene => {
        const pref = scenes[scene] || {};
        return scene + ': ' + (pref.preferred_tier || 'auto') +
          ' a=' + (pref.accept_count || 0) + ' r=' + (pref.reject_count || 0);
      });
      const quietUntil = preferences.global_voice_quiet_until || 0;
      const quiet = quietUntil > Date.now() / 1000 ? 'voice quiet active' : '';
      return entries.concat(quiet ? [quiet] : []).join('\\n') || '-';
    }
    function formatBudget(budget) {
      if (!budget) return '-';
      return ['voice', 'motion', 'subtitle'].map(name => {
        const row = budget[name] || {};
        return name + '=' + (row.remaining !== undefined ? row.remaining : '-') + '/' + (row.limit !== undefined ? row.limit : '-');
      }).join(' / ');
    }
    function set(id, text, cls) {
      const el = document.getElementById(id);
      el.textContent = text;
      el.className = cls || '';
    }
    async function sendTest(scenario) {
      const res = await fetch('/api/test-event', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenario })
      });
      const data = await res.json();
      document.getElementById('last-test').textContent = JSON.stringify(data, null, 2);
      refresh();
    }
    refresh();
    setInterval(refresh, 1000);
  </script>
</body>
</html>
"""


def main() -> None:
    mouse_hook = threading.Thread(target=mouse_hook_loop, name="mouse-wheel-hook", daemon=True)
    mouse_hook.start()
    sampler = threading.Thread(target=sampler_loop, name="desktop-sampler", daemon=True)
    sampler.start()
    poster = threading.Thread(target=backend_post_loop, name="backend-poster", daemon=True)
    poster.start()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"Desktop Rhythm Agent running at http://{HOST}:{PORT}")
    print(f"Sampling foreground window every {SAMPLE_INTERVAL_SECONDS}s.")
    if BACKEND_POST_ENABLED:
        print(f"Posting desktop context to {BACKEND_DESKTOP_CONTEXT_URL} every {BACKEND_POST_INTERVAL_SECONDS}s.")
    else:
        print("Backend posting disabled.")
    print("Press Ctrl+C to stop.")
    server.serve_forever()


if __name__ == "__main__":
    main()

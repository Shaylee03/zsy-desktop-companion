param(
  [string]$ConfigPath = ""
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
  $ConfigPath = Join-Path $Root "config.local.json"
}
$ExamplePath = Join-Path $Root "config.example.json"
$RuntimeDir = Join-Path $Root ".runtime"
$PidPath = Join-Path $RuntimeDir "desktop-agent.pid"

if (!(Test-Path -LiteralPath $ConfigPath)) {
  if (!(Test-Path -LiteralPath $ExamplePath)) {
    throw "Missing config.local.json and config.example.json."
  }
  Copy-Item -LiteralPath $ExamplePath -Destination $ConfigPath
  Write-Host "Created config.local.json from config.example.json. Edit it before connecting a real robot."
}

$config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
if (!(Test-Path -LiteralPath $RuntimeDir)) {
  New-Item -ItemType Directory -Path $RuntimeDir | Out-Null
}

if (Test-Path -LiteralPath $PidPath) {
  $oldPid = (Get-Content -LiteralPath $PidPath -Raw).Trim()
  if ($oldPid -and (Get-Process -Id ([int]$oldPid) -ErrorAction SilentlyContinue)) {
    Write-Host "Desktop agent is already running. PID: $oldPid"
    if ($config.openPanelOnStart -ne $false) {
      Start-Process ("http://127.0.0.1:{0}" -f $config.agentPort)
    }
    exit 0
  }
}

if ($config.backendDesktopContextUrl) {
  $env:DESKTOP_AGENT_BACKEND_URL = [string]$config.backendDesktopContextUrl
}
if ($null -ne $config.debugToken -and [string]$config.debugToken -ne "") {
  $env:DESKTOP_AGENT_DEBUG_TOKEN = [string]$config.debugToken
}
if ($null -ne $config.postBackend) {
  $env:DESKTOP_AGENT_POST_BACKEND = if ($config.postBackend) { "1" } else { "0" }
}
if ($config.agentPort) {
  $env:DESKTOP_AGENT_PORT = [string]$config.agentPort
}
if ($config.activityWatchUrl) {
  $env:ACTIVITYWATCH_URL = [string]$config.activityWatchUrl
}
if ($config.backendPostIntervalSeconds) {
  $env:DESKTOP_AGENT_BACKEND_INTERVAL = [string]$config.backendPostIntervalSeconds
}

$python = (Get-Command python -ErrorAction SilentlyContinue)
if (!$python) {
  throw "Python was not found in PATH. Install Python 3.10+ before running the desktop agent."
}

$agentPath = Join-Path $Root "agent.py"
if (!(Test-Path -LiteralPath $agentPath)) {
  throw "Missing agent.py in $Root."
}

$process = Start-Process `
  -FilePath $python.Source `
  -ArgumentList @($agentPath) `
  -WorkingDirectory $Root `
  -WindowStyle Minimized `
  -PassThru

Set-Content -LiteralPath $PidPath -Value ([string]$process.Id)
Write-Host ("Desktop agent started. PID: {0}" -f $process.Id)
Write-Host ("Panel: http://127.0.0.1:{0}" -f $config.agentPort)

Start-Sleep -Seconds 2
if ($config.openPanelOnStart -ne $false) {
  Start-Process ("http://127.0.0.1:{0}" -f $config.agentPort)
}

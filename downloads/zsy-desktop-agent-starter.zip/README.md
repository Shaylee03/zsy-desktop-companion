# Desktop Rhythm Agent

Local Windows agent for observing desktop work context before connecting it to
the robot policy layer.

The first version is intentionally visible and testable. It runs a local web
panel and JSON API, but does not control the robot by itself.

The observer now follows an ActivityWatch-style pattern: a background sampler
collects signals continuously, and the web/API layer reads the latest cached
state. This keeps the panel responsive and makes foreground-window changes show
up quickly.

By default it also posts a compact desktop-context summary to the backend every
5 seconds so the backend can run robot rhythm policies.

## What It Collects

- Active foreground process and window title.
- Keyboard/mouse idle seconds.
- WeChat L1-L2 signals:
  - whether WeChat is running;
  - whether WeChat is foreground;
  - visible WeChat window titles;
  - unread hint from taskbar/window title when available.
- Optional ActivityWatch probe:
  - whether the local ActivityWatch API is reachable;
  - latest buckets summary when available;
  - latest `aw-watcher-window` app/title event;
  - latest `aw-watcher-afk` status event;
  - recent 30-minute app usage summary;
  - recent 30-minute active/AFK seconds.

## Sampling

- Foreground window, idle time, visible WeChat windows: every 0.5s by default.
- WeChat process check: every 3s by default.
- ActivityWatch API probe: every 5s by default with a short timeout.

These can be tuned with environment variables:

```powershell
$env:DESKTOP_AGENT_SAMPLE_INTERVAL="0.3"
$env:DESKTOP_AGENT_WECHAT_INTERVAL="2"
$env:DESKTOP_AGENT_AW_INTERVAL="5"
$env:DESKTOP_AGENT_BACKEND_INTERVAL="5"
python .\local_agent\agent.py
```

Disable backend posting when you only want the local panel:

```powershell
$env:DESKTOP_AGENT_POST_BACKEND="0"
python .\local_agent\agent.py
```

## State Model

The agent reports independent tracks instead of a single exclusive state:

```json
{
  "interaction": "unknown",
  "tasks": [],
  "work_context": {
    "activity": "coding|meeting|wechat|browser|away|unknown",
    "active_app": "Code.exe",
    "window_title": "server.py"
  },
  "attention_hint": "allow_speak|quiet|do_not_disturb"
}
```

Timer/focus/reminder tasks remain backend-owned. This local agent only reports
desktop context, so it will not conflict with existing timer guard behavior.

## Run

```powershell
python .\local_agent\agent.py
```

Then open:

```text
http://127.0.0.1:8765
```

JSON endpoints:

```text
GET  /api/state
POST /api/test-event
```

## Portable Starter Mode

For a transferable prototype, use the included Windows launcher scripts:

```powershell
cd .\local_agent
Copy-Item .\config.example.json .\config.local.json
notepad .\config.local.json
powershell -ExecutionPolicy Bypass -File .\Start-ZSY-Desktop-Agent.ps1
```

The launcher reads `config.local.json`, sets the required environment
variables, starts `agent.py`, stores the process id in `.runtime`, and opens the
local panel.

To stop the agent:

```powershell
powershell -ExecutionPolicy Bypass -File .\Stop-ZSY-Desktop-Agent.ps1
```

To create desktop shortcuts for non-technical testers:

```powershell
powershell -ExecutionPolicy Bypass -File .\Create-Desktop-Shortcuts.ps1
```

`config.local.json` is intentionally local-only. It can contain a tester's own
backend URL and pairing token, so it should not be committed or shared.

Minimum transferable setup:

- Windows 10/11.
- Python 3.10+ in PATH.
- Optional ActivityWatch at `http://127.0.0.1:5600` for richer app/AFK context.
- A backend that accepts `POST /desktop-context`.
- A robot already paired to that backend. The local agent sends desktop context;
  the backend remains responsible for deciding quiet/subtle/subtitle/speak.

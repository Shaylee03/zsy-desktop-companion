$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Desktop = [Environment]::GetFolderPath("Desktop")
$Shell = New-Object -ComObject WScript.Shell

function New-AgentShortcut {
  param(
    [string]$Name,
    [string]$TargetScript
  )

  $shortcutPath = Join-Path $Desktop $Name
  $shortcut = $Shell.CreateShortcut($shortcutPath)
  $shortcut.TargetPath = "powershell.exe"
  $shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$TargetScript`""
  $shortcut.WorkingDirectory = $Root
  $shortcut.IconLocation = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe,0"
  $shortcut.Save()
  Write-Host "Created shortcut: $shortcutPath"
}

New-AgentShortcut -Name "Start ZSY Desktop Agent.lnk" -TargetScript (Join-Path $Root "Start-ZSY-Desktop-Agent.ps1")
New-AgentShortcut -Name "Stop ZSY Desktop Agent.lnk" -TargetScript (Join-Path $Root "Stop-ZSY-Desktop-Agent.ps1")

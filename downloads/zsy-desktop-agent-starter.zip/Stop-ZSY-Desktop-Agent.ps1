$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$PidPath = Join-Path $Root ".runtime\desktop-agent.pid"

if (!(Test-Path -LiteralPath $PidPath)) {
  Write-Host "No desktop-agent.pid file found. Nothing to stop."
  exit 0
}

$pidValue = (Get-Content -LiteralPath $PidPath -Raw).Trim()
if (!$pidValue) {
  Remove-Item -LiteralPath $PidPath -Force
  Write-Host "Empty PID file removed."
  exit 0
}

$process = Get-Process -Id ([int]$pidValue) -ErrorAction SilentlyContinue
if ($process) {
  Stop-Process -Id $process.Id -Force
  Write-Host ("Desktop agent stopped. PID: {0}" -f $process.Id)
} else {
  Write-Host ("PID {0} is not running." -f $pidValue)
}

Remove-Item -LiteralPath $PidPath -Force
